import React, { useState } from "react";
import CSVReader from "react-csv-reader"; //https://www.npmjs.com/package/react-csv-reader
import { Paper, Container, Button, Switch, FormControlLabel  } from '@material-ui/core';
import { createMuiTheme, ThemeProvider } from "@material-ui/core/styles";
import { Grid, Table, TableHeaderRow, PagingPanel, TableEditColumn, TableEditRow } from "@devexpress/dx-react-grid-material-ui";
import { PagingState, SortingState, IntegratedPaging, EditingState, IntegratedSorting } from '@devexpress/dx-react-grid';
import PublishIcon from '@material-ui/icons/Publish';
import FormatClearIcon from '@material-ui/icons/FormatClear';
import './csv.css'


const parseOptions = {
    header: true,
    dynamicTyping: true,
    skipEmptyLines: true,
};

const getRowId = row => row.id;

export default function ReadCSV() {
    const [rows, setRows] = useState([]);

    const [columns] = useState([
    { name: "partNumber", title: "Part Number" },
    { name: "description", title: "Description" },
    { name: "price", title: "Price" },
    { name: "category", title: "Category" },
    { name: "companyId", title: "Company Id" },
    { name: "lifecycle", title: "Lifecycle" },
    { name: "revision", title: "Revision" },
    { name: "vehicleModel", title: "Vehicle Model" },
    ]);

    const [darkState, setDarkState] = useState(false);
    const palletType = darkState ? "light" : "dark";
    const darkTheme = createMuiTheme({
        palette: {
        type: palletType,
        }
    });

    
    const handleTheme = () => {
        setDarkState(!darkState);
    }

    const handleData = (data) => {
        let x = data.map((item, index) => {
            return { id: index , ...item }
        });
        setRows(x);
    };

    const handleClearData = () => {
        setRows([]);
    }

    const commitChanges = ({ added, changed, deleted }) => {
        let changedRows;

        if (added) {
            const startingAddedId = rows.length > 0 ? rows[rows.length - 1].id + 1 : 0;
            
            changedRows = [
                ...rows,
                ...added.map((row, index) => (
                        { id: startingAddedId + index, ...row }
                )),
            ];

            }
            if (changed) {
                changedRows = rows.map(row => (changed[row.id] ? { ...row, ...changed[row.id] } : row));
            }
            if (deleted) {
                const deletedSet = new Set(deleted);
                changedRows = rows.filter(row => !deletedSet.has(row.id));
            }
            
            setRows(changedRows);
        };
        
    return (
    <div>
        <ThemeProvider theme={darkTheme}>
            <div className="file">
            <CSVReader
                cssClass="react-csv-input"
                // label="Select CSV with secret Death Star statistics"
                onFileLoaded={(data) => handleData(data)}
                parserOptions={parseOptions}
                inputStyle={{color: 'white'}}
            />    
            </div>

            <Container maxWidth="xl">
            <FormControlLabel
            control={<Switch onChange={ handleTheme } color="primary" />}
            label="Switch Theme"
            />
                <Paper>
                    <Grid 
                        rows={rows} 
                        columns={columns} 
                        getRowId={getRowId}
                    >
                        <EditingState
                            onCommitChanges={commitChanges}
                        />
                        <PagingState
                            defaultCurrentPage={0}
                            pageSize={10}
                        />
                        <SortingState
                            defaultSorting={[{ columnName: 'id', direction: 'asc' }]}
                        />
                        <IntegratedPaging />
                        <IntegratedSorting />
                        <Table />
                        <TableHeaderRow showSortingControls />
                        <TableEditColumn
                            showAddCommand
                            showEditCommand
                            showDeleteCommand
                        />
                        <PagingPanel />
                        <TableEditRow />
                    </Grid>
                </Paper>

                <Button variant="contained" color="primary" size="large" className="submit">
                    Submit
                    <PublishIcon />    
                </Button>
                <Button variant="contained" style={{ backgroundColor: "red", color: "white" }} size="large" className="submit" onClick={ handleClearData }>
                    Clear  
                    <FormatClearIcon />
                </Button>
            </Container>
        </ThemeProvider>
    </div>
    );
}
